﻿CREATE TABLE [dbo].[Oppurtunity]
(
	[Opp_ID] INT NOT NULL PRIMARY KEY, 
    [Opp_Name] NVARCHAR(50) NOT NULL, 
    [Opp_Date] DATE NOT NULL, 
    [Opp_Center] NVARCHAR(50) NOT NULL
)
