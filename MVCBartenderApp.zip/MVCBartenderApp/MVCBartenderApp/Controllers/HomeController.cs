﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MVCBartenderApp.Models;

namespace MVCBartenderApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

      



        private static List<CocktailOrderModel> cocktails = new List<CocktailOrderModel>()
        {
            new CocktailOrderModel{ Name = "OLD FASHIONED", Description = "This simple classic made with rye or bourbon, a sugar cube, Angostura bitters, a thick cube of ice, and an orange twist delivers every time.", Price= 10.5 },
        new CocktailOrderModel{Name = "Espresso Martini", Description = "A great crafted coffee and vodka cocktail.", Price= 8.25 },
        new CocktailOrderModel {Name = "Dry Martini", Description = "It uses half-and-half gin to French vermouth, a dash of orange bitters, a squeeze of lemon and a green olive.", Price= 9 },
        new CocktailOrderModel{Name = "Manhattan ", Description = "Rye whiskey, sweet vermouth and two dashes of Angostura, stirred with ice, strained into a chilled coupe and garnished with brandied cherries.", Price= 11 },
        new CocktailOrderModel{Name = "Aperol Spritz ", Description = "Aperol, prosseco and a splash of soda.", Price= 5.50 },
         new CocktailOrderModel{Name = "Mojito ", Description = "rum, lime juice, soda, brown cane sugar, fresh mint and ice.", Price= 8.25 }
        };

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View(cocktails);
        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
