﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MVCBartenderApp.Models;

namespace MVCBartenderApp.Controllers
{
    public class BartenderList : Controller
    {
        public static List<CocktailOrderModel> InQueue = new List<CocktailOrderModel>();

        private static int currentId = 0;

        public IActionResult List(CocktailOrderModel cocktail)
        {
            return View(InQueue);
        }

        public RedirectToActionResult Create(CocktailOrderModel cocktail)
        {
            cocktail.CocktailID = ++currentId;
           
              InQueue.Add(cocktail);

            return RedirectToAction("Index", "Home");
        }


        public RedirectToActionResult Delete(CocktailOrderModel cocktail)
        {
           
            InQueue.RemoveAll( x => x.CocktailID == cocktail.CocktailID);

            return RedirectToAction("List");
        }
    }
}
