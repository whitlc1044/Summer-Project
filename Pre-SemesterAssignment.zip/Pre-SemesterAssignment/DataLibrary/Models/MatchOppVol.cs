﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLibrary.Models
{
    public class MatchOppVol
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string UserName { get; set; }

        public string Opp_Name { get; set; }

        public string Opp_Center { get; set; }

        public string Opp_Desc { get; set; }


    }
}
