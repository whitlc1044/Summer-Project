﻿using System;

namespace DataLibrary
{
    public class Class1
    {
    }
}
